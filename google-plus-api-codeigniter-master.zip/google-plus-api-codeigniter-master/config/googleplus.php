<?php
$config['googleplus']['application_name'] = '';
$config['googleplus']['client_id'] = '';
$config['googleplus']['client_secret'] = '';
$config['googleplus']['redirect_uri'] = '';
$config['googleplus']['api_key'] = '';
?>
